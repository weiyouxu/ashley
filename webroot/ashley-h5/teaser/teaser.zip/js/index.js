var ww = $(window).width();
var wh = $(window).height();

$('.wrapper').width(ww);
$('.wrapper').height(wh);